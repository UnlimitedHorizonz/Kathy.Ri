public class Exercise01_02 {
  public static void main(String[] args) {
    System.out.println("Welcome to Java");
    System.out.println("Welcome to Java");
    System.out.println("Welcome to Java");
    System.out.println("Welcome to Java");
    System.out.println("Welcome to Java");
  }
}
