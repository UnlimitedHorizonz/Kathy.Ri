public class Exercise03_16 {
  public static void main(String[] args) {
    double x = Math.random() * 100 - 50;
    double y = Math.random() * 200 - 100;
    
    System.out.println(x + ", " + y);
  }
}
